package com.rafapps.simplenotes;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NameAuthenticationActivity extends AppCompatActivity {

    private EditText username_in;
    private Button username_submit;
    private int INTERNET_PERMISSION_REQUEST_CODE = 100001;
    private int ACCESS_NETWORK_STATE_REQUEST_CODE = 100002;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_username_authentication);
        username_submit = findViewById(R.id.username_submit);
        username_in = findViewById(R.id.username_in);


        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.INTERNET)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission has already been granted
            // Do your work here
            System.out.println("INTERNET GRANTED");
        } else {
            // Permission is not yet granted
            // Request for permission
            System.out.println("INTERNET NOT GRANTED");
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.INTERNET},
                    INTERNET_PERMISSION_REQUEST_CODE);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission has already been granted
            // Do your work here
            System.out.println("ACCESS NET STATE GRANTED");
        } else {
            // Permission is not yet granted
            // Request for permission
            System.out.println("ACCESS NET STATE NOT GRANTED");
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_NETWORK_STATE},
                    ACCESS_NETWORK_STATE_REQUEST_CODE);
        }

        username_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = username_in.getText().toString();
                Intent switchActivityIntent = new Intent(NameAuthenticationActivity.this, PasswdAuthenticationActivity.class);
                switchActivityIntent.putExtra("username", username);
                startActivity(switchActivityIntent);
            }
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission has been granted
                // Do your work here
        } else {
                // Permission has been denied
                // Handle the situation gracefully
        }
    }
}
