package com.rafapps.simplenotes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


public class PasswdAuthenticationActivity extends AppCompatActivity {
    private TextView passwd_msg;
    private Button passwd_submit;
    private EditText passwd_in;
    private ClientAuth clientauth = new ClientAuth();
    private boolean isConfirmationPending = false;
    private String initialPasswd= "";
    private String username= "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwd_authentication);
        passwd_in = findViewById(R.id.username_in);
        passwd_submit = findViewById(R.id.username_submit);
        passwd_msg = findViewById(R.id.username_msg);

        username = getIntent().getStringExtra("username");
        boolean valid = clientauth.checkPassword(username);

        if (valid) {
            passwd_msg.setText("Enter your password:");
            passwd_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String password = passwd_in.getText().toString();
                    boolean passwordValid = clientauth.verifyPassword(username, password);

                    if (passwordValid) {
                        System.out.println("Password entered by user is correct");

                        Intent noteintent = new Intent(PasswdAuthenticationActivity.this, NotesListActivity.class);
                        noteintent.putExtra("username", username);
                        noteintent.putExtra("password", password);
                        startActivity(noteintent);
                    } else {
                        Toast.makeText(PasswdAuthenticationActivity.this, "Invalid password.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
            });
        } else {
            if (!isConfirmationPending) {
                passwd_msg.setText("Enter a new password:");
            } else {
                passwd_msg.setText("Confirm password:");
            }

            passwd_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String password = passwd_in.getText().toString();

                    if (clientauth.isBlank(password)) {
                        Toast.makeText(PasswdAuthenticationActivity.this, "Password cannot be blank.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String regex = "^(?=.*[A-Za-z])(?=.*\\d).{8,64}$";
                    if (!password.matches(regex)) {
                       Toast.makeText(PasswdAuthenticationActivity.this, "Password must be at least 8 characters long, contain at least one alphabet and one number, and not exceed 64 characters.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!isConfirmationPending) {
                        isConfirmationPending = true;
                        initialPasswd = password;
                        passwd_in.setText("");
                        passwd_msg.setText("Confirm password:");
                    } else if (!initialPasswd.equals(password)) {
                        Toast.makeText(PasswdAuthenticationActivity.this, "Passwords do not match. Please try again.", Toast.LENGTH_SHORT).show();
                        isConfirmationPending= false;
                        initialPasswd = "";
                        passwd_in.setText("");
                        passwd_msg.setText("Enter a new password:");
                    } else {
                        boolean passwordValid = clientauth.registerPassword(username, password);

                        if (passwordValid) {
                            Intent noteintent = new Intent(PasswdAuthenticationActivity.this, NotesListActivity.class);
                            noteintent.putExtra("username", username);
                            noteintent.putExtra("password", password);
                            startActivity(noteintent);
                        } else {
                           Toast.makeText(PasswdAuthenticationActivity.this, "Error registering user, please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }

    }
}