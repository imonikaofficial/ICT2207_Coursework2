package com.rafapps.simplenotes;


import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.MGF1ParameterSpec;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.SecretKeySpec;

public class ClientAuth {
    byte[] delimiter = {0};
    String serverIP = "40.114.111.27";
    int serverport = 18537;

    byte[] server_response;

    public void run_server(byte[] message) {
        Runnable myRunnable = new Runnable() {
            @Override
            public void run() {
                server_response = query_server(message);
            }
        };

        Thread server_request_Thread = new Thread(myRunnable);

        server_request_Thread.start();

        try {
            server_request_Thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private byte[] query_server(byte[] message) {
        byte[] buffer = new byte[1024];

        try {
            //System.out.println("Connecting");
            Socket clientSocket = new Socket(serverIP, serverport);

            //System.out.println("Connected to " + clientSocket.getRemoteSocketAddress());

            // send data to the server
            OutputStream outputStream = clientSocket.getOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            dataOutputStream.write(message);

            // receive data from the server
            InputStream inputStream = clientSocket.getInputStream();
            int bytesRead = inputStream.read(buffer);

            // close the socket
            clientSocket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return buffer;
    }
    private byte[] SHA256_hash_password(String password) {
        byte[] hashedOutput = null;

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            hashedOutput = md.digest(password.getBytes());

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return hashedOutput;
    }

    public byte[] get_aes_key_from_server(String username, String password) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        //hash password, send message

        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        KeyPair pair = generator.generateKeyPair();
        PrivateKey privateKey = pair.getPrivate();
        PublicKey publicKey = pair.getPublic();
        byte[] publicKeyBytes = publicKey.getEncoded();
        //System.out.println(Arrays.toString(publicKeyBytes));

        byte[] hash_password = SHA256_hash_password(password);
        byte[] username_bytes = username.getBytes();
        byte[] message = new byte[hash_password.length + username_bytes.length + publicKeyBytes.length + 7];
        byte[] bytelength = ByteBuffer.allocate(4).putInt(hash_password.length + username_bytes.length + publicKeyBytes.length + 7).array();



        System.arraycopy(bytelength, 0, message, 0, 4);
        message[4] = 4;
        System.arraycopy(username_bytes, 0, message, 5, username_bytes.length);
        message[username_bytes.length + 5] = 0;
        System.arraycopy(hash_password, 0, message, username_bytes.length + 6, hash_password.length);
        message[username_bytes.length + hash_password.length + 6] = 0;
        System.arraycopy(publicKeyBytes, 0, message, username_bytes.length + hash_password.length + 7, publicKeyBytes.length);
        run_server(message);

        byte[] key = Arrays.copyOfRange(server_response, 5, 261);

        //System.out.println(Arrays.toString(test));

        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        OAEPParameterSpec oaepSpec = new OAEPParameterSpec(
                "SHA-256", "MGF1", new MGF1ParameterSpec("SHA-256"), PSource.PSpecified.DEFAULT
        );
        // Decrypt the AES key using the private key
        cipher.init(Cipher.DECRYPT_MODE, privateKey, oaepSpec);
        byte[] plainText = cipher.doFinal(key);
        //System.out.println(Arrays.toString(plainText));

        return plainText;

    }

    private byte[] aes_encrypt(byte[] data, byte[] key) throws Exception {
        byte[] iv = "fedcba9876543210".getBytes(); // 256-bit (IV) for 256-bit AES key

        // create the cipher object
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

        // initialize the cipher object with the key and IV
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

        // encrypt the plaintext
        byte[] cipherText = cipher.doFinal(data);

        // print the ciphertext
        return cipherText;
    }

    private byte[] aes_decrypt(byte[] data, byte[] key) throws Exception {
        byte[] iv = "fedcba9876543210".getBytes(); // 256-bit (IV) for 256-bit AES key

        // create the cipher object
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

        // initialize the cipher object with the key and IV
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

        // encrypt the plaintext
        byte[] plainText = cipher.doFinal(data);

        // print the ciphertext
        return plainText;
    }

    public String decrypt_data(String username, String password, byte[] data) throws Exception {
        byte[] key = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        boolean key_obtained = false;
        while (!key_obtained) {
            try {
                key = get_aes_key_from_server(username, password);
                key_obtained = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        byte[] decrypted_data = aes_decrypt(data, key);
        System.out.println(Arrays.toString(decrypted_data));
        return new String(decrypted_data, StandardCharsets.UTF_8);

    }

    public byte[] encrypt_data(String username, String password, String data) throws Exception {
        byte[] key = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        boolean key_obtained = false;
        while (!key_obtained) {
            try {
                key = get_aes_key_from_server(username, password);
                key_obtained = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        byte[] encrypted_data = aes_encrypt(data.getBytes(), key);
        System.out.println(Arrays.toString(encrypted_data));
        return encrypted_data;
    }

    private boolean database_search_for_id(String username) {
        byte[] username_bytes = username.getBytes();
        byte[] message = new byte[username_bytes.length + 5];
        byte[] bytelength = ByteBuffer.allocate(4).putInt(username_bytes.length + 1).array();
        System.arraycopy(bytelength, 0, message, 0, 4);
        message[4] = 1;
        System.arraycopy(username_bytes, 0, message, 5, username_bytes.length);
        run_server(message);

        System.out.println(Arrays.toString(server_response));
        System.out.println(server_response[5]);
        if (server_response[5] == 1) {
            System.out.println("user found!");
            return true;
        }
        System.out.println("user not found.");
        return false;
    }
    private boolean database_compare_hash(String username, String password) {
        //hash password, send message
        byte[] hash_password = SHA256_hash_password(password);
        byte[] username_bytes = username.getBytes();
        byte[] message = new byte[hash_password.length + username_bytes.length + 6];
        byte[] bytelength = ByteBuffer.allocate(4).putInt(hash_password.length + username_bytes.length + 2).array();

        System.arraycopy(bytelength, 0, message, 0, 4);
        message[4] = 2;
        System.arraycopy(username_bytes, 0, message, 5, username_bytes.length);
        message[username_bytes.length + 5] = 0;
        System.arraycopy(hash_password, 0, message, username_bytes.length + 6, hash_password.length);
        run_server(message);

        System.out.println(Arrays.toString(server_response));
        System.out.println(server_response[5]);
        if (server_response[5] == 1) {
            System.out.println("login success!");
            return true;
        }
        System.out.println("bad password!");
        return false;
    }
    public boolean verifyPassword(String username, String password) {
        if (database_compare_hash(username, password)) {
            return true;
        }
        return false;
    }

    public boolean checkPassword(String username) {
        //check_database
        if (database_search_for_id(username)) {
            return true;
        }
        return false;
    }

    public boolean isBlank(String password) {
        if (password.length() < 1) {
            return true;
        }
        return false;
    }

    public boolean registerPassword(String username, String password) {
        byte[] hash_password = SHA256_hash_password(password);
        byte[] username_bytes = username.getBytes();
        byte[] message = new byte[hash_password.length + username_bytes.length + 6];
        byte[] bytelength = ByteBuffer.allocate(4).putInt(hash_password.length + username_bytes.length + 2).array();

        System.arraycopy(bytelength, 0, message, 0, 4);
        message[4] = 3;
        System.arraycopy(username_bytes, 0, message, 5, username_bytes.length);
        message[username_bytes.length + 5] = 0;
        System.arraycopy(hash_password, 0, message, username_bytes.length + 6, hash_password.length);
        run_server(message);

        System.out.println(Arrays.toString(server_response));
        System.out.println(server_response[5]);
        if (server_response[5] == 1) {
            System.out.println("register success!");
            return true;
        }
        System.out.println("user already exists!");
        return false;
    }
}
